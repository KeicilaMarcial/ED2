
/*-------------------Cabeçalho das funções---------------------------*/
No* novoNo(int chave);
void rotacaoE(No**T, No* x);
void rotacaoD(No**T, No* y);
void insereArvoreConserta(No** Root, No* New);
void insereRB(No** T, int chave);
void Imprime(No* Root, int nivel);
No* consulta_Arv(No** raiz, int valor);
void **RemoverNo(No **raiz, int elemento);
No *Sucessor(No *raiz);
No *RemoverNaArvore(No *raiz, No *x);
/*------------------------------------------------------------------*/
    